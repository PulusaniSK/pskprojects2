
# JavaScript Todo App

## This is simple javascript todo app project made with html, css, js, and localstorage.

